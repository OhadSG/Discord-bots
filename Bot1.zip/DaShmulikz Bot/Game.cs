﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DaShmulikz_Bot
{
    public class Game
    {
        public string gameName;
        public int teamSize;

        public Game(string _gameName, int _teamSize)
        {
            gameName = _gameName;
            teamSize = _teamSize;
        }
    }
}
