﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Discord.Rest;

namespace DaShmulikz_Bot
{
    public class PrivateRoom
    {
        public SocketUser owner;
        public string password;
        public RestTextChannel text;

        public PrivateRoom(SocketUser _owner, RestTextChannel _text)
        {
            owner = _owner;
            text = _text;
            password = "";
        }

        public void SetPassword(string _password)
        {
            password = _password;
        }
    }
}
