﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DaShmulikz_Bot
{
    public class Cache
    {
        public static Dictionary<ulong, PrivateRoom> privateRooms = new Dictionary<ulong, PrivateRoom>();
    }
}
