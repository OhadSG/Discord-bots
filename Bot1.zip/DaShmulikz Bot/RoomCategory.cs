﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DaShmulikz_Bot
{
    class RoomCategory
    {
        static List<RoomCategory> roomCategories = new List<RoomCategory>();

        ulong ServerID;
        ulong CategoryID;
        ulong ChannelID;

        public RoomCategory(ulong _ServerID, ulong _CategoryID, ulong _ChannelID)
        {
            ServerID = _ServerID;
            CategoryID = _CategoryID;
            ChannelID = _ChannelID;
            roomCategories.Add(this);
        }

        public static void AddRoomsCategory(ulong ServerID, ulong CategoryID, ulong ChannelID)
        {
            new RoomCategory(ServerID, CategoryID, ChannelID);
            DBFunctions.CreateRoomsCategory(ServerID, CategoryID, ChannelID);
        }

    }
}
