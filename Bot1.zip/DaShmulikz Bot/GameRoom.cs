﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Discord.Rest;

namespace DaShmulikz_Bot
{
    public class GameRoom : PrivateRoom
    {
        Game game;

        public static Dictionary<string, Game> games = new Dictionary<string, Game>()
        {
            {"5PA", new Game("5v5 Pro am", 5)},
            {"3PA", new Game("3v3 Pro am", 3) },
            {"2P", new Game("2v2 Park", 2)},
            {"1MC", new Game("1v1 MyCourt", 2) },
            {"5R", new Game("5v5 Rec", 5) },
            {"3P", new Game("3v3 Park", 3) }
        };
        public GameRoom(Game _game, PrivateRoom _room) : base(_room.owner,  _room.text)
        {
            game = _game;
        }

        public static async void PrintGames(RestTextChannel channel)
        {
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.Title = "Games";
            embed.Description = "";

            foreach (string key in games.Keys)
            {
                embed.Description += $"**{key}**: {games[key].gameName}\n";    
            }

            await channel.SendMessageAsync(embed: embed.Build());
        }
    }
}
