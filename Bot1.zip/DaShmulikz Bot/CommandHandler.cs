﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Reflection;

namespace DaShmulikz_Bot
{
    class CommandHandler
    {
        public static char PREFIX = '#';

        private DiscordSocketClient _client;
        public static CommandService _commands;

        public CommandHandler(DiscordSocketClient client, CommandService commands)
        {
            _commands = commands;
            _client = client;
        }

        public async Task InstallCommandsAsync()
        {
            _client.MessageReceived += HandleCommandAsync;

            Console.WriteLine(_commands.AddModulesAsync(Assembly.GetEntryAssembly(), null).Result.ToString());
        }

        private async Task HandleCommandAsync(SocketMessage msg)
        {
            SocketUserMessage message = msg as SocketUserMessage;
            if (message == null) return;

            int argPos = 0;

            if (!(message.HasCharPrefix(PREFIX, ref argPos) || message.HasMentionPrefix(_client.CurrentUser, ref argPos)) || message.Author.IsBot)
                return;
            Console.WriteLine(message.Content);
            var context = new SocketCommandContext(_client, message);

            IResult result = await _commands.ExecuteAsync(context: context, argPos: argPos, services: null);

            if (!result.IsSuccess)
            {
                EmbedBuilder embed = new EmbedBuilder();
                embed.WithColor(Color.Red);
                embed.Title = "ERROR";
                embed.Description = result.ErrorReason.TrimEnd('.');
                await context.Channel.SendMessageAsync(embed: embed.Build());
            }
        }
    }
}
