﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Discord.Rest;
using System.Globalization;


namespace DaShmulikz_Bot
{
    public class CommandModule : ModuleBase<SocketCommandContext>
    {
        [Command("Help", RunMode = RunMode.Async)]
        public async Task Help()
        {
            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.Title = $"Commands ({CommandHandler.PREFIX})";

            if ((Context.Message.Author as SocketGuildUser).Roles.ToList().Exists(x => x.Id == 785451414335389706))
            {
                string admin = "**AddRoomsCategory**: Create a private rooms section\n\n"
                            + "**AddReactionRole <MessageID> <@Role> <:Emote:>**: Add a reaction which grants a role when selected\n\n"
                            + "**SendEmbed <r> <g> <b> <{Title};{Message}>**: Send am embed with the inputed color, title and description\n\n"
                            + "**Clear <num>**: Delete <num> messages from the current channel\n";
                embed.AddField("@admin", admin);
            }
            string everyone = $"**Join <@User> <Password>**: Join the @User's private room\n\n"
                            + "**SetGameRoom <Game>**: Set the current private channel as a game room `[Room owner only]`\n\n"
                            + "**SetPassword <Password>**: Set a password for the current private room `[Room owner only]`\n\n"
                            + "**SetUserLimit <Limit>**: Set the user limit for the current private room `[Room owner only]`\n";
            embed.AddField("@everyone", everyone);


            await Context.Channel.SendMessageAsync(embed: embed.Build());
        }

        [Command("Clear", RunMode = RunMode.Async)]
        [RequireUserPermission(GuildPermission.ManageMessages, ErrorMessage = "You do not have permission to use this command")]
        public async Task Clear(int x)
        {
            var channel = Context.Channel as SocketTextChannel;
            var messages = await Context.Channel.GetMessagesAsync(x + 1).FlattenAsync();
            await channel.DeleteMessagesAsync(messages);
        }

        [Command("SendEmbed")]
        [RequireUserPermission(GuildPermission.Administrator, ErrorMessage = "You do not have permission to use this command")]
        public async Task SendEmbed(int r = 255, int g = 127, int b = 80, [Remainder] string msg = "ENTER MESSAGE")
        {
            EmbedBuilder embed = new EmbedBuilder();
            bool isR = r >= 0 && r < 256;
            bool isG = g >= 0 && g < 256;
            bool isB = b >= 0 && b < 256;

            if (isR && isG && isB)
            {
                embed.WithColor(r, g, b);
                string[] split = msg.Split(';');
                if (split.Length == 2)
                {
                    embed.WithTitle(split[0]);
                    embed.Description = split[1];

                    await Context.Channel.SendMessageAsync(embed: embed.Build());
                    EmbedBuilder embed2 = new EmbedBuilder()
                        .WithCurrentTimestamp()
                        .WithFooter(Context.Guild.Name)
                        .WithTitle("Here's your embed code in case you need it again :)")
                        .WithDescription(Context.Message.Content.Replace("*", "\\*"));
                    await Context.User.GetOrCreateDMChannelAsync().Result.SendMessageAsync(embed: embed2.Build());
                    await Context.Message.DeleteAsync();
                }
                else
                {
                    await Context.Channel.SendMessageAsync("Message is not in the required format (Title;Description)");
                }
            }
            else
            {
                await Context.Channel.SendFileAsync("Color invalid");
            }
        }

        [RequireUserPermission(GuildPermission.Administrator, ErrorMessage = "You do not have permission to use this command")]
        [Command("AddReactionRole", RunMode = RunMode.Async)]
        public async Task AddReactionRole(ulong messageID, string _role, string _emote)
        {
            bool is_message, is_role, is_emote;

            var message = await Context.Channel.GetMessageAsync(messageID);
            var role = Context.Guild.GetRole(BotFunctions.GetRoleIDFromString(_role));

            is_emote = Emote.TryParse(_emote, out Emote emote);
            Emoji emoji = null;
            if (!is_emote)
            {
                emoji = new Emoji(_emote);
                is_emote = emoji != null;
            }

            is_message = message != null;
            is_role = role != null;

            if (!is_message)
            {
                await Context.Channel.SendMessageAsync("Couldn't find a message matching that message ID in this channel");
            }
            else if (!is_role)
            {
                await Context.Channel.SendMessageAsync("You must mention a role");
            }
            else if (!is_emote)
            {
                await Context.Channel.SendMessageAsync("Invalid emote");
            }
            else
            {
                foreach (ReactionRole r in ReactionRole.reactionRoles)
                {
                    if (r.messageID == messageID)
                    {
                        if (r.roleID == role.Id)
                        {
                            await Context.Channel.SendMessageAsync("The mentioned role is already linked to the specified message");
                            return;
                        }
                        if (r.emoteID == (emoji != null ? BotFunctions.Encode(emoji.Name) : emote.Id.ToString()))
                        {
                            await Context.Channel.SendMessageAsync("You can't use the same emote for different roles");
                            return;
                        }
                    }
                }

                ReactionRole.AddReactionRole(messageID, role.Id, emoji != null ? BotFunctions.Encode(emoji.Name) : emote.Id.ToString());
                await Context.Message.DeleteAsync();
                await message.AddReactionAsync(emoji != null ? (emoji as IEmote) : emote);
                Console.WriteLine(emoji != null ? (emoji as IEmote) : emote);
            }
        }

        [RequireUserPermission(GuildPermission.Administrator, ErrorMessage = "You do not have permission to use this command")]
        [Command("AddRoomsCategory", RunMode = RunMode.Async)]
        public async Task CreateRoomsCategory()
        {
            var category = await Context.Guild.CreateCategoryChannelAsync("Private Voice Channels");
            var waiting = await Context.Guild.CreateVoiceChannelAsync("Waiting Room", p => { p.CategoryId = category.Id; });
            await waiting.AddPermissionOverwriteAsync(Context.Guild.EveryoneRole, new OverwritePermissions(moveMembers: PermValue.Allow));
            var room = await Context.Guild.CreateVoiceChannelAsync("Create Private Channel", p => { p.CategoryId = category.Id; });
            RoomCategory.AddRoomsCategory(Context.Guild.Id, category.Id, room.Id);
        }

        // the ulong is the voice chat ID, PrivateRoom contains owner and text channel
        [Command("Join", RunMode = RunMode.Async)]
        public async Task Join(SocketGuildUser user, string password = "")
        {
            if (await BotFunctions.IsJoinable(Context, user, password))
            {
                await (Context.User as SocketGuildUser).ModifyAsync(p => { p.Channel = user.VoiceChannel; });
                if(password != "")
                    await Context.Message.DeleteAsync();
            }
        }

        [Command("SetGameRoom", RunMode = RunMode.Async)]
        public async Task SetGameRoom([Remainder] string gameName)
        {
            if (await BotFunctions.IsOwner(Context))
            {
                Game x;
                if (!GameRoom.games.TryGetValue(gameName.ToUpper(), out x))
                    x = new Game(gameName, 10);

                Cache.privateRooms[(Context.User as SocketGuildUser).VoiceChannel.Id] = new GameRoom(x, Cache.privateRooms[(Context.User as SocketGuildUser).VoiceChannel.Id]);
                await (Context.User as SocketGuildUser).VoiceChannel.ModifyAsync(p => {p.Name = $"{x.gameName}"; p.UserLimit = x.teamSize; });
                await Cache.privateRooms[(Context.User as SocketGuildUser).VoiceChannel.Id].text.ModifyAsync(p => {p.Name = $"{x.gameName.Replace(' ', '_')}"; });
            }
        }

        [Command("SetPassword", RunMode = RunMode.Async)]
        public async Task SetPassword([Remainder]string password)
        {
            if (await BotFunctions.IsOwner(Context))
            {
                ulong roomID = (Context.User as SocketGuildUser).VoiceChannel.Id;
                Cache.privateRooms[(Context.User as SocketGuildUser).VoiceChannel.Id].SetPassword(password);
                await Context.Guild.GetVoiceChannel(roomID).AddPermissionOverwriteAsync(Context.Guild.EveryoneRole, new OverwritePermissions(connect: PermValue.Deny));
                await Context.Message.DeleteAsync();
                await Context.Channel.SendMessageAsync("Password set!");
            }
        }

        [Command("SetUserLimit", RunMode = RunMode.Async)]
        public async Task SetUserLimit(int lim) //gimme a sec trying to fix discord
        {
            if (await BotFunctions.IsOwner(Context))
            {
                if (lim > 0)
                    await (Context.User as SocketGuildUser).VoiceChannel.ModifyAsync(p => { p.UserLimit = lim; });
                else
                    await Context.Channel.SendMessageAsync("Limit must be bigger than 0");
            }
        }
    } 
}
