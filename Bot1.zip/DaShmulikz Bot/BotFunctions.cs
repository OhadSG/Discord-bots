﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Discord.Rest;
using System.Globalization;

namespace DaShmulikz_Bot
{
    public class BotFunctions
    {
        public static async Task CreatePrivateRoom(SocketGuild guild, SocketUser user, ulong? CategoryID)
        {
            //784397264281403423  member
            bool exists = guild.Roles.ToList().Exists(x => x.Id == 784397264281403423);
            var role = guild.Roles.ToList().Find(x => x.Id == 784397264281403423);

            var room = await guild.CreateVoiceChannelAsync($"{user.Username} החדר של", p => { p.CategoryId = CategoryID; });
            await room.AddPermissionOverwriteAsync(guild.EveryoneRole, new OverwritePermissions(viewChannel: PermValue.Deny, connect: PermValue.Allow));
            await room.AddPermissionOverwriteAsync(user, new OverwritePermissions(moveMembers: PermValue.Allow, connect: PermValue.Allow));
            if(exists)
                await room.AddPermissionOverwriteAsync(role, new OverwritePermissions(viewChannel: PermValue.Allow, connect: PermValue.Allow));

            var textRoom = await guild.CreateTextChannelAsync($"{user.Username} הצ'אט של", p => { p.CategoryId = CategoryID; });
            await textRoom.AddPermissionOverwriteAsync(guild.EveryoneRole, new OverwritePermissions(viewChannel: PermValue.Deny));
            await textRoom.AddPermissionOverwriteAsync(user, new OverwritePermissions(viewChannel: PermValue.Allow));
            if (exists)
                await room.AddPermissionOverwriteAsync(role, new OverwritePermissions(viewChannel: PermValue.Allow));

            EmbedBuilder embed = new EmbedBuilder();
            embed.Color = Color.Green;
            embed.Title = "Welcome to your private room!";
            embed.Description = $"Type **{CommandHandler.PREFIX}SetPassword <Password>** to set the channel's password\n"
                + $"Use **{CommandHandler.PREFIX}SetGameRoom <Game>** to set the channel as a private game room\n"
                + $"Use **{CommandHandler.PREFIX}SetUserLimit <Number>** to set the channel's user limit";

            await textRoom.SendMessageAsync(embed: embed.Build());
            GameRoom.PrintGames(textRoom);


            Cache.privateRooms.Add(room.Id, new PrivateRoom(user, textRoom));
            await textRoom.SendMessageAsync(user.Mention);
            
            try
            {
                await (user as SocketGuildUser).ModifyAsync(u => { u.Channel = room; });
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                await room.DeleteAsync();
                await BotFunctions.DeletePrivateRoom(room.Id);
            }
        }

        public static async Task DeletePrivateRoom(SocketGuild guild, ulong channelID)
        {
            await guild.GetVoiceChannel(channelID).DeleteAsync();
            await Cache.privateRooms[channelID].text.DeleteAsync();
            Cache.privateRooms.Remove(channelID);
        }

        public static async Task DeletePrivateRoom(ulong channelID)
        {
            await Cache.privateRooms[channelID].text.DeleteAsync();
            Cache.privateRooms.Remove(channelID);
        }

        public static async Task GrantTextPerms(SocketUser user, ulong channelID)
        {
            await Cache.privateRooms[channelID].text.AddPermissionOverwriteAsync(user, new OverwritePermissions(viewChannel: PermValue.Allow));
        }
        
        public static async Task<bool> IsOwner(SocketCommandContext _context)
        {
            var vc = (_context.User as SocketGuildUser).VoiceChannel;
            if(vc == null) return false;

            bool is_private_room = Cache.privateRooms.TryGetValue(vc.Id, out PrivateRoom x);
            bool is_owner = is_private_room ? _context.User == x.owner : false;

            if (is_owner) return true;

            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.Title = "ERROR";
            if(!is_private_room)
                embed.WithDescription("You must be connected to a private channel to use this comment");
            else
                embed.WithDescription("You must be the owner of the private channel you are trying to modify");

            await _context.Channel.SendMessageAsync(embed: embed.Build());
            return false;
        }

        public static async Task<bool> IsJoinable(SocketCommandContext _context, SocketGuildUser user, string password)
        {
            var vc = user.VoiceChannel;

            bool is_moveable = (_context.User as SocketGuildUser).VoiceChannel != null;
            bool is_joinable = vc != null && _context.Guild.Id == user.VoiceChannel.Guild.Id;
            bool is_private_room = Cache.privateRooms.TryGetValue(user.VoiceChannel.Id, out PrivateRoom x);
            bool is_password_correct = is_private_room ? password == x.password : false;

            if (is_moveable && is_joinable && is_password_correct) return true;

            EmbedBuilder embed = new EmbedBuilder();
            embed.WithColor(Color.Red);
            embed.Title = "ERROR";

            if (!is_moveable)
                embed.WithDescription("You must be connected to a voice channel");
            else if(!is_joinable)
                embed.WithDescription("You must be connected to the same server as the user you want to join");
            else if(!is_private_room)
                embed.WithDescription("The room you are trying to join is not a private room");
            else
                embed.WithDescription("Wrong password");

            await _context.Channel.SendMessageAsync(embed: embed.Build());
            return false;
        }

        public static ulong GetRoleIDFromString(string _role)
        {
            string roleID = "";


            for(int i = 0; i < _role.Length; i++)
            {
                if(IsDigit(_role[i]))
                    roleID += _role[i];
            }

            return ulong.Parse(roleID);
        }

        public static bool IsDigit(char c)
        {
            char[] digits = new char[]
            {
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
            };

            for (int i = 0; i < digits.Length; i++)
            {
                if (c == digits[i])
                    return true;
            }

            return false;
        }

        public static IRole GetRole(Cacheable<IUserMessage, ulong> message, SocketReaction reaction)
        {
            var guild = (message.DownloadAsync().Result.Channel as SocketGuildChannel).Guild;

            bool is_emote = reaction.Emote is Emote;
            string e = BotFunctions.Encode(reaction.Emote.Name);
            try
            {
                ulong roleID = ReactionRole.GetRoleID(message.Id, is_emote ? ((Emote)reaction.Emote).Id.ToString() : e);
                return guild.GetRole(roleID);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return null;

        }

        public static void CacheRoomCategories(List<ulong> x)
        {
            for (int i = 0; i < x.Count; i += 3)
            {
                new RoomCategory(x[i], x[i + 1], x[i + 2]);
            }
        }

        public static void CacheReactionRoles(List<string> x)
        {
            for (int i = 0; i < x.Count; i += 3)
            {
                new ReactionRole(ulong.Parse(x[i]), ulong.Parse(x[i + 1]), x[i + 2]);
            }
        }

        public static string @Encode(string value)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in value)
            {
                if (c > 127)
                {
                    // This character is too big for ASCII
                    string encodedValue = "\\u" + ((int)c).ToString("x4");
                    sb.Append(encodedValue);
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

    }
}
