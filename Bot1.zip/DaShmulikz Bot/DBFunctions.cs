﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord.Commands;
using System.Data;
using System.Data.SqlClient;

namespace DaShmulikz_Bot
{
    public class DBFunctions
    {

        public static void ExecuteNonQuery(string commandText)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=DaShmulikz;"))
            {
                SqlCommand command = new SqlCommand(commandText, connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        public static object ExecuteScalar(string commandText)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=DaShmulikz;"))
            {
                SqlCommand command = new SqlCommand(commandText, connection);
                connection.Open();
                var ret = command.ExecuteScalar();
                connection.Close();
                return ret;
            }
        }

        public static void CreateRoomsCategory(ulong ServerID, ulong CategoryID, ulong ChannelID)
        {
            string query = " INSERT INTO Categories([ServerID], [CategoryID], [ChannelID]) " +
            String.Format(" VALUES('{0}', '{1}', '{2}') ", ServerID, CategoryID, ChannelID);
            ExecuteNonQuery(query);
        }

        public static bool IsCreateRoom(ulong ChannelID)
        {
            return (int)ExecuteScalar( $" SELECT COUNT([ChannelID]) FROM Categories WHERE [ChannelID] = '{ChannelID}' ") == 1 ? true : false;
        }

        public static void AddReactionRole(ulong MessageID, ulong RoleID, string EmoteID)
        {
            string query = " INSERT INTO ReactionRoles([MessageID], [RoleID], [EmoteID]) " +
            String.Format(" VALUES('{0}', '{1}', '{2}') ", MessageID, RoleID, EmoteID);
            ExecuteNonQuery(query);
        }

        public static void DeleteRRByMessage(ulong MessageID)
        {
            string query = $" DELETE FROM ReactionRoles WHERE [MessageID] = '{MessageID}' ";
            ExecuteNonQuery(query);
        }

        public static void DeleteRRByRole(ulong RoleID)
        {
            string query = $" DELETE FROM ReactionRoles WHERE [RoleID] = '{RoleID}' ";
            ExecuteNonQuery(query);
        }

        public static long GetRoleID(ulong MessageID, string EmoteID)
        {
            return (long)ExecuteScalar($" SELECT [RoleID] FROM ReactionRoles WHERE [MessageID] = '{MessageID}' AND [EmoteID] = '{EmoteID}' ");
        }


        public static List<ulong> GetAllCategories()
        {
            List<ulong> attributes = new List<ulong>();
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=DaShmulikz;");
            conn.Open();

            string select = " SELECT [ServerID], [CategoryID], [ChannelID] FROM Categories ";
            SqlCommand cmd = new SqlCommand(select, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
                for (int i = 0; i < 3; i++)
                    attributes.Add(ulong.Parse(((IDataRecord)reader)[i].ToString()));

            conn.Close();
            return attributes;
        }

        public static List<string> GetAllReactionRoles()
        {
            List<string> attributes = new List<string>();
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=DaShmulikz;");
            conn.Open();

            string select = " SELECT [messageID], [roleID], [emoteID] FROM ReactionRoles ";
            SqlCommand cmd = new SqlCommand(select, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
                for (int i = 0; i < 3; i++)
                    attributes.Add(BotFunctions.Encode(((IDataRecord)reader)[i].ToString()));

            conn.Close();
            return attributes;
        }

        /*
















        public static void InsertUpdateUser(ulong ServerID, ulong DiscordID, string ingameName, string PlayerID)
        {
            string query = "";
            if (UsernameExists(ServerID, DiscordID))
            {
                query = $" UPDATE Users SET [IngameName] = '{ingameName}', [PlayerID] = '{PlayerID}', [LeaderboardChange] = 0, [LeaderboardPosition] = 0 WHERE [DiscordID] = '{DiscordID}' ";
            }
            else
            {
                query = " INSERT INTO Users([DiscordID], [IngameName], [PlayerID], [LeaderboardChange], [LeaderboardPosition]) " +
                String.Format(" VALUES('{0}', '{1}', '{2}', 0, 0) ", DiscordID, ingameName, PlayerID);
            }
            ExecuteNonQuery(ServerID, query);
        }
        //update to new format
        public static bool DeleteUser(ulong ServerID, ulong discordID)
        {
            if (UsernameExists(ServerID, discordID))
            {
                string query = $" DELETE FROM Users WHERE [DiscordID] = '{discordID}' ";
                ExecuteNonQuery(ServerID, query);
                return true;
            }
            return false;
        }
        public static bool UsernameExists(ulong ServerID, ulong DiscordID)
        {
            return (int)ExecuteScalar(ServerID, " SELECT COUNT([discordID]) FROM Users WHERE[DiscordID] = '" + DiscordID + "' ") > 0 ? true : false;
        }
        //update to new format
        public static List<string> SelectUsersAttribute(ulong ServerID, string attribute)
        {
            string id = "r6" + ServerID;
            List<string> attributes = new List<string>();
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=" + id + ";");
            conn.Open();

            string select = " SELECT [" + attribute + "] FROM Users ";
            SqlCommand cmd = new SqlCommand(select, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
                attributes.Add(reader[attribute].ToString());

            conn.Close();
            return attributes;
        }
        public static object SelectUserAttribute(ulong ServerID, ulong DiscordID, string attribute)
        {
            string query = $" SELECT [{attribute}] FROM Users WHERE [DiscordID] = '{DiscordID}'";
            return ExecuteScalar(ServerID, query);
        }
        public static object GetLobbyAttribute(ulong ChannelID, string attribute)
        {
            string query = $" SELECT [{attribute}] FROM Lobbies WHERE [ChannelID] = '{ChannelID}'";
            return ExecuteScalar(0, query);
        }
        public static void UpdateMMR(ulong ServerID, ulong discordID, int mmr)
        {
            ExecuteNonQuery(ServerID, " UPDATE Users SET [MMR] = '" + mmr + "' WHERE [DiscordID] = '" + discordID + "' ");
        }
        //FIX
        public static List<string> GetLeaderboard(ulong ServerID)
        {
            int i = 0;
            List<string> leaderboard = new List<string>();

            using (SqlConnection conn = new SqlConnection($@"Data Source=(localdb)\ProjectsV13;Initial Catalog=r6{ServerID};"))
            using (SqlConnection conn2 = new SqlConnection($@"Data Source=(localdb)\ProjectsV13;Initial Catalog={ServerID};"))
            {
                SqlCommand cmd = new SqlCommand(" SELECT [DiscordID] FROM Users ORDER BY [MMR] DESC", conn);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    i++;

                    leaderboard.Add(reader["DiscordID"].ToString());
                    string query = $" UPDATE Users SET [LeaderboardChange] = [LeaderboardPosition] - {i}, [LeaderboardPosition] = {i} WHERE [DiscordID] = '{leaderboard[i - 1]}' ";
                    ExecuteNonQuery(query);

                }
                conn.Close();
            }

            return leaderboard;
        }
        //FIX
        public static bool CheckDatabaseExists(ulong ServerID)
        {
            string sqlCreateDBQuery;
            bool result = false;

            try
            {
                sqlCreateDBQuery = $"SELECT database_id FROM sys.databases WHERE name = 'r6{ServerID}'";
                using (SqlConnection tmpConn = new SqlConnection(@"Data Source = (localdb)\ProjectsV13;"))
                {
                    using (SqlCommand sqlCmd = new SqlCommand(sqlCreateDBQuery, tmpConn))
                    {
                        tmpConn.Open();
                        object resultObj = sqlCmd.ExecuteScalar();
                        int databaseID = 0;

                        if (resultObj != null)
                        {
                            int.TryParse(resultObj.ToString(), out databaseID);
                        }

                        tmpConn.Close();
                        result = (databaseID > 0);
                    }
                }
            }
            catch (Exception e)
            {
                result = false;
                Console.WriteLine(e.Message);
            }
            return result;
        }
        //FIX
        public static void CreateDatabase(ulong ServerID)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source = (localdb)\ProjectsV13;"))
            {
                string query = string.Format("CREATE DATABASE {0};", "r6" + ServerID);
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            ExecuteNonQuery(ServerID, "CREATE TABLE [dbo].[Users] ([Id] INT IDENTITY(1, 1) NOT NULL, [DiscordID] NVARCHAR(37) NOT NULL, [IngameName] NVARCHAR(16) NOT NULL, [mmr] INT NULL, [PlayerID] NVARCHAR(100) NULL, [LeaderboardPosition] INT NULL, [LeaderboardChange] INT NULL, PRIMARY KEY CLUSTERED([Id] ASC));");
        }

        public static void AddLobby(ulong ServerID, ulong CategoryID, ulong ChannelID, int MinMMR, int MaxMMR)
        {
            if (!IsLobby(ChannelID))
            {
                string query = " INSERT INTO Lobbies([ServerID], [CategoryID], [ChannelID], [MinMMR], [MaxMMR]) " +
                String.Format(" VALUES('{0}', '{1}', '{2}', '{3}', '{4}') ", ServerID, CategoryID, ChannelID, MinMMR, MaxMMR);
                ExecuteNonQuery(0, query);
            }
        }

        public static void RemoveLobby(ulong ChannelID)
        {
            if (IsLobby(ChannelID))
            {
                string query = $" DELETE Lobbies WHERE ChannelID = '{ChannelID}' ";
                ExecuteNonQuery(0, query);
            }
        }

        public static bool IsLobby(ulong ChannelID)
        {
            string query = $" SELECT COUNT([ChannelID]) FROM Lobbies WHERE[ChannelID] = '{ChannelID}' ";
            return (int)ExecuteScalar(0, query) > 0 ? true : false;
        }
        public static ulong GetLobbyCategory(ulong ChannelID)
        {
            string query = $" SELECT [CategoryID] FROM Lobbies WHERE[ChannelID] = '{ChannelID}' ";
            return ulong.Parse(ExecuteScalar(0, query).ToString());
        }

        public static int GetMinMMR(ulong ChannelID)
        {
            string query = $" SELECT [MinMMR] FROM Lobbies WHERE[ChannelID] = '{ChannelID}' ";
            return (int)ExecuteScalar(0, query);
        }
        public static int GetMaxMMR(ulong ChannelID)
        {
            string query = $" SELECT [MaxMMR] FROM Lobbies WHERE[ChannelID] = '{ChannelID}' ";
            return (int)ExecuteScalar(0, query);
        }

        public static void SetLogChannel(ulong ServerID, ulong ChannelID)
        {
            string query = "";
            if (!HasLogChannel(ServerID))
            {
                query = " INSERT INTO LogChannels([ServerID], [ChannelID]) " +
                String.Format(" VALUES('{0}', '{1}') ", ServerID, ChannelID);
            }
            else
            {
                query = $" UPDATE LogChannels SET [ChannelID] = '{ChannelID}' WHERE [ServerID] = '{ServerID}' ";
                ExecuteNonQuery(0, query);
            }
            ExecuteNonQuery(0, query);
        }

        public static bool HasLogChannel(ulong ServerID)
        {
            string query = $" SELECT COUNT([ChannelID]) FROM LogChannels WHERE[ServerID] = '{ServerID}' ";
            return (int)ExecuteScalar(0, query) > 0 ? true : false;
        }

        public static ulong GetLogChannel(ulong ServerID)
        {
            string query = $" SELECT [ChannelID] FROM LogChannels WHERE[ServerID] = '{ServerID}' ";
            return ulong.Parse(ExecuteScalar(0, query).ToString());
        }

        */
    }
}

