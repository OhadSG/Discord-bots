﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DaShmulikz_Bot
{
    class ReactionRole
    {

        public static List<ReactionRole> reactionRoles = new List<ReactionRole>();

        public ulong messageID;
        public ulong roleID;
        public string emoteID;

        public ReactionRole(ulong _messageID, ulong _roleID, string _emoteID)
        {
            messageID = _messageID;
            roleID = _roleID;
            emoteID = _emoteID;
            reactionRoles.Add(this);
        }

        public static void AddReactionRole(ulong MessageID, ulong RoleID, string EmoteID)
        {
            new ReactionRole(MessageID, RoleID, EmoteID);
            DBFunctions.AddReactionRole(MessageID, RoleID, EmoteID);
        }

        public static void DeleteRRByMessage(ulong MessageID)
        {
            for (int i = reactionRoles.Count - 1; i >= 0; i--)
            {
                if (reactionRoles[i].messageID == MessageID)
                    reactionRoles.RemoveAt(i);
            }
            DBFunctions.DeleteRRByMessage(MessageID);
        }

        public static void DeleteRRByRole(ulong RoleID)
        {
            for (int i = reactionRoles.Count - 1; i >= 0; i--)
            {
                if (reactionRoles[i].roleID == RoleID)
                    reactionRoles.RemoveAt(i);
            }

            DBFunctions.DeleteRRByRole(RoleID);
        }

        public static ulong GetRoleID(ulong MessageID, string EmoteID)
        {
            foreach (ReactionRole r in reactionRoles)
            {
                if (r.messageID == MessageID && r.emoteID == EmoteID)
                {
                    return r.roleID;
                }
            }

            throw new Exception("Reaction Role not found");
        }
    }
}
