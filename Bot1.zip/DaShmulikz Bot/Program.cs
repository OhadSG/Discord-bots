﻿using Discord;
using Discord.Commands;
using Discord.Rest;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Timers;

namespace DaShmulikz_Bot
{
    class Program
    {
        public static DiscordSocketClient statclient;

        private DiscordSocketClient _client;
        private CommandService _commands;

        public static void Main(string[] args)
            => new Program().MainAsync().GetAwaiter().GetResult();


        public async Task MainAsync()
        {
            CommandServiceConfig cmdConfig = new CommandServiceConfig();
            cmdConfig.DefaultRunMode = RunMode.Async;
            _commands = new CommandService(cmdConfig);

            DiscordSocketConfig config = new DiscordSocketConfig();
            config.AlwaysDownloadUsers = true;
            config.MessageCacheSize = 100;

            _client = new DiscordSocketClient(config);
            _client.Log += Log;
            _client.UserVoiceStateUpdated += UserVoiceStateUpdated;

            _client.ReactionAdded += ReactionAdded;
            _client.ReactionRemoved += ReactionRemoved;
            _client.ReactionsCleared += ReactionsCleared;
            _client.MessageDeleted += MessageDeleted;
            _client.MessagesBulkDeleted += MessagesBulkDeleted;
            _client.RoleDeleted += RoleDeleted;
            _client.Ready += Ready;

            CommandHandler cmdHandler = new CommandHandler(_client, _commands);
            await cmdHandler.InstallCommandsAsync();
            statclient = _client;
            await _client.LoginAsync(TokenType.Bot, "NzY4MTgzMTk4NDExNzg0MTky.X48wWg.L1atGW6ZuzG5PqitpGyJ9ENy0wQ");
            await _client.StartAsync();

            await Task.Delay(-1);
        }


        private Task Log(LogMessage msg)
        {
            Console.WriteLine(msg.ToString());
            return Task.CompletedTask;
        }

        private async Task UserVoiceStateUpdated(SocketUser user, SocketVoiceState before, SocketVoiceState after)
        {
            if(before.VoiceChannel != null && Cache.privateRooms.TryGetValue(before.VoiceChannel.Id, out PrivateRoom x))
            {
                if (before.VoiceChannel.Users.Count == 0)
                    await BotFunctions.DeletePrivateRoom(before.VoiceChannel.Guild, before.VoiceChannel.Id);
            }

            if(after.VoiceChannel != null && DBFunctions.IsCreateRoom(after.VoiceChannel.Id))
            {
                await BotFunctions.CreatePrivateRoom(after.VoiceChannel.Guild, user, after.VoiceChannel.CategoryId);
            }

            if(after.VoiceChannel != null && Cache.privateRooms.ContainsKey(after.VoiceChannel.Id))
            {
                await BotFunctions.GrantTextPerms(user ,after.VoiceChannel.Id);
            }
        }

        private Task RoleDeleted(SocketRole role)
        {
            ReactionRole.DeleteRRByRole(role.Id);
            return Task.CompletedTask;
        }

        private Task MessagesBulkDeleted(IReadOnlyCollection<Cacheable<IMessage, ulong>> messages, ISocketMessageChannel channel)
        {
            var iter = messages.GetEnumerator();
            
            while (iter.MoveNext())
            {
                ReactionRole.DeleteRRByMessage(iter.Current.Id);
            }
            return Task.CompletedTask;

        }

        private Task MessageDeleted(Cacheable<IMessage, ulong> message, ISocketMessageChannel channel)
        {
            ReactionRole.DeleteRRByMessage(message.Id);
            return Task.CompletedTask;

        }

        private Task ReactionsCleared(Cacheable<IUserMessage, ulong> message, ISocketMessageChannel channel)
        {
            ReactionRole.DeleteRRByMessage(message.Id);
            return Task.CompletedTask;

        }

        private Task ReactionRemoved(Cacheable<IUserMessage, ulong> message, ISocketMessageChannel channel, SocketReaction reaction)
        {
            SocketGuildUser user = ((SocketGuildChannel)channel).Guild.GetUser(reaction.UserId);

            Console.WriteLine($"{user.Nickname}: {reaction.Emote.Name}");

            IRole role = BotFunctions.GetRole(message, reaction);

            if (role != null)
            {
                Console.WriteLine("success");
                user.RemoveRoleAsync(role);
            }


            return Task.CompletedTask;
        }

        private Task ReactionAdded(Cacheable<IUserMessage, ulong> message, ISocketMessageChannel channel, SocketReaction reaction)
        {
            SocketGuildUser user = ((SocketGuildChannel)channel).Guild.GetUser(reaction.UserId);

            Console.WriteLine($"{user.Nickname}: {reaction.Emote.Name}");

            IRole role = BotFunctions.GetRole(message, reaction);

            if (role != null)
            {
                Console.WriteLine("success");
                user.AddRoleAsync(role);
            }


            return Task.CompletedTask;
        }

        private Task Ready()
        {
            BotFunctions.CacheReactionRoles(DBFunctions.GetAllReactionRoles());
            BotFunctions.CacheRoomCategories(DBFunctions.GetAllCategories());

            _client.SetGameAsync($"{CommandHandler.PREFIX}help");

            Console.WriteLine("Ready!!");
            return Task.CompletedTask;
        }
    }
}
